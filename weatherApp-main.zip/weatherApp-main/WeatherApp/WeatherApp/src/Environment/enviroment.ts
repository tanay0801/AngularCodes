export const environment = {
    production : false,
    weatherApiBaseUrl : 'https://open-weather13.p.rapidapi.com/city',
    XRapidAPIHostHeaderName : 'X-RapidAPI-Host',
    XRapidAPIHostHeaderValue : 'open-weather13.p.rapidapi.com',
    XRapidAPIKeyHeaderName : 'X-RapidAPI-Key',
    XRapidAPIKeyValue : 'ee554c2996msh8452215582f456fp169846jsn98d199e8ab7b'
};