# weatherApp
An Angular weather application.

>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

An Angular project which gathers data from an API and displays to the front-end. 
You can Search locations to gather weather data, it shows sunrise image for Hot weather and night image as cold weather. 
I have used angular forms to accept input from the user.

To use this you must have Angular installed in your PC.

>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

Import the project in your workspace and locate the project in the terminal and enter following command : 
 -> ng serve ==> to start the server (also to start the application).
